.. include:: ../release/0.5.2-notes.rst
