.. _ref-thresholding:
.. currentmodule:: pywt

Thresholding functions
======================

The :mod:`~pywt.thresholding` helper module implements the most popular signal
thresholding functions.


Thresholding
------------

.. autofunction:: threshold
